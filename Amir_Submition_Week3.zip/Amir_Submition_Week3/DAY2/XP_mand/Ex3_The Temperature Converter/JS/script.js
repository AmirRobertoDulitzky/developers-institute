let cel = 38;
// let fer = (cel /5) * 9 +32;
let fer = (cel * 1.8) +32;
console.log(`${cel}C is ${fer}F`);

