let favoriteFood = `Tom's ramen`;

let favoriteMeal = `breakfast`;

console.log(`I eat ${favoriteFood} at every ${favoriteMeal}.`);



